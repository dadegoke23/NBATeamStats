__version__ = '0.2.17'

__pdoc__ = {
    '__version__': "The version of the installed nfldb module.",
}
